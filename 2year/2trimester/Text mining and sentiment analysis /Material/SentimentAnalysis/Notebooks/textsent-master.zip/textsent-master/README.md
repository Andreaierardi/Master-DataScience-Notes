# textsent
Examples and code chunks for the course of text mining and sentiment analysis.

## Note
##### DATA DOWNLOADS

- yelp_example_1_small.tsv: https://island.ricerca.di.unimi.it/~alfio/shared/yelp_example_1_small.tsv
- Brat-project: http://island.ricerca.di.unimi.it/home/alfio/public_html/shared/textsent/brat-project.zip

